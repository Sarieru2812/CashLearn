document.addEventListener('DOMContentLoaded', () => {
    const balloons = document.querySelectorAll('.balloon');
    const contents = document.querySelectorAll('.content');
  
    balloons.forEach(balloon => {
      balloon.addEventListener('click', () => {
        // Esconde todo o conteúdo
        contents.forEach(content => content.classList.add('hidden'));
  
        // Exibe o conteúdo correspondente ao balão clicado
        const targetId = balloon.getAttribute('data-target');
        const targetContent = document.getElementById(targetId);
        if (targetContent) {
          targetContent.classList.remove('hidden');
        }
      });
    });
  });
  